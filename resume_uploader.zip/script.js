function openTab(event, tabName) {
    let tabs = document.querySelectorAll(".tab-content");
    tabs.forEach(tab => tab.classList.remove("active"));

    let buttons = document.querySelectorAll(".tab-button");
    buttons.forEach(btn => btn.classList.remove("active"));

    document.getElementById(tabName).classList.add("active");
    event.currentTarget.classList.add("active");
}

// Set the first tab as active by default
document.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".tab-button").click();
});